import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DataGridComponent } from './modules/data-grid/data-grid.component';
import { TableGridComponent } from './modules/table-grid/table-grid.component';

// ROUTES
const routes: Routes = [
  {
    path: '',
    component: DataGridComponent,
    children: [
      {
        path: 'DataGridComponent',
        loadChildren: '~modules/data-grid/data-grid.module#DataGridModule',
      },
    ]
  },
  {
    path: 'table-grid',
    component: TableGridComponent,
    children: [
      {
        path: 'TableGridComponent',
        loadChildren: '~modules/table-grid/table-grid.module#TableGridModule',
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

